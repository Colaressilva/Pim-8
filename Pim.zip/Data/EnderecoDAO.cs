﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Models;

namespace $safeprojectname$.Data
{
    public class EnderecoDAO : DbContext
    {
        public EnderecoDAO (DbContextOptions<EnderecoDAO> options)
            : base(options)
        {
        }

        public DbSet<$safeprojectname$.Models.endereco> endereco { get; set; }
    }
}
