﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using $safeprojectname$.Models;

namespace $safeprojectname$.Data
{
    public class TelefoneDAO : DbContext
    {
        public TelefoneDAO (DbContextOptions<TelefoneDAO> options)
            : base(options)
        {
        }

        public DbSet<$safeprojectname$.Models.telefone> telefone { get; set; }
    }
}
