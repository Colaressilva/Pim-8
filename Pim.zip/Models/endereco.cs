﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class endereco
    {
        [Key]
        protected int id;
        public int Id { get => id; set => id = value; }

        [Required(ErrorMessage = "O campo logradouro é obrigatório")]
        public string logradouro { get; set; }
        [Required(ErrorMessage = "O campo número é obrigatório")]

        protected int numero;
        [Required(ErrorMessage = "O campo Número é obrigatório")]
        public int Numero { get => numero; set => numero = value; }

        protected int cep;
        [Required(ErrorMessage = "O campo CEP é obrigatório")]
        public int Cep { get => cep; set => cep = value; }

        [Required(ErrorMessage = "O campo Bairro é obrigatório")]
        public string bairro { get; set; }
        [Required(ErrorMessage = "O campo cidade é obrigatório")]
        public string cidade { get; set; }
        [Required(ErrorMessage = "O campo estado é obrigatório")]
        public string estado { get; set; }
    }
}