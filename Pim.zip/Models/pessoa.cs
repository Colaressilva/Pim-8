﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class pessoa
    {
        [Key]
        private int id;
        public int Id { get => id; set => id = value; }

        [Required(ErrorMessage = "O campo Nome é obrigatório")]
        public string Nome { get; set; }
        
        protected int endereco { get; set; }
        [Required(ErrorMessage = "O campo Endereço é obrigatório")]
        public int Endereco { get => endereco; set => endereco = value; }

        protected string cpf { get; set; }
        [Required(ErrorMessage = "O campo CPF é obrigatório")]
        public string Cpf { get => cpf; set => cpf = value; }
    }
}
