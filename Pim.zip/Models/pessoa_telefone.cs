﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class pessoa_telefone : pessoa
    {
        [Key]
        protected int id_pessoa;
        public int Id_pessoa { get => id_pessoa; set => id_pessoa = value; }

        protected int id_telefone;
        public int Id_telefone { get => id_telefone; set => id_telefone = value; }
    }
}
