﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models;

public class telefone : telefone_tipo
{
    [Key]
    private int id;
    public int Id { get => id; set => id = value; }

    protected int numero;
    [Required(ErrorMessage = "O campo Numero é obrigatório")]
    public int Numero { get => numero; set => numero = value; }

    protected int ddd;
    [Required(ErrorMessage = "O campo DDD é obrigatório")]
    public int DDD { get => ddd; set => ddd = value; }

    protected int tipo;
    [Required(ErrorMessage = "O campo Tipo é obrigatório")]
    public int Tipo { get => tipo; set => tipo = value; }
}
