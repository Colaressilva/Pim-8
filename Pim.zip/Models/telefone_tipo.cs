﻿using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{
    public class telefone_tipo
    {
        [Key]
        private int id;
        public int Id { get => id; set => id = value; }
        public int Tipo { get; set; }
    }
}
